# VibeStarters

**Tested vibe coding prompt packs + AI agent starters that actually ship.**

Free core library for people who build with Cursor, Claude Code, Lovable, Bolt, and similar tools — especially those into AI agents, tech, and games.

## What’s inside (v1)

| Pack | Description |
|------|-------------|
| [01 – Core Vibe Coding](packs/01-core-vibe-coding.md) | Project rules, start app, add feature, debug, UI polish |
| [02 – Agent Loop Starters](packs/02-agent-loop-starters.md) | Research → plan → implement → verify patterns |
| [03 – Simple Game Systems](packs/03-game-systems.md) | Player controller, game loop, spawner, juice |
| [04 – Cursor & Claude Rules](packs/04-cursor-claude-rules.md) | Drop-in rules and safe starters |

All prompts follow a consistent, battle-tested structure so the AI plans first and stays constrained.

## How to use
1. Open the pack you need.
2. Copy the prompt.
3. Replace the `[brackets]`.
4. Paste into your AI coding tool.
5. Force a plan on anything non-trivial.

## Roadmap
- More packs (auth flows, multiplayer basics, agent evaluation, etc.)
- Lightweight site with search + copy buttons
- Weekly signal newsletter (new packs + high-signal tips)
- Premium / sponsor packs later (only when it feels natural)

## Feedback
Open an issue or reply on X. We iterate based on what actually works for people.

---

Built and maintained as an autonomous project.  
License: MIT (prompts free to use and remix)
