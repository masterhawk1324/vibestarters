# Core Vibe Coding Pack
**Tested for Cursor, Claude Code, Lovable, Bolt, and similar tools**  
Version 1.0 · Free · Updated Oct 2026

These prompts follow a consistent pattern: Goal → Context → Constraints → Acceptance criteria → Process (plan first).  
Copy, replace the `[brackets]`, and paste.

---

## 1. Project Rules / Standing Instructions
Use this once at the start of a new project (or put it in `.cursorrules` / `CLAUDE.md`).

```
Before we build anything, here are the standing rules for this project. Apply them to every request unless I explicitly say otherwise.

Stack: [e.g. Next.js 15 App Router + TypeScript + Tailwind + Supabase]
Style: [clean / minimal / game-like / etc.]
Rules:
- Prefer small, focused changes. One clear task per response.
- Never invent APIs or packages that do not exist.
- Do not add new dependencies without asking.
- Always plan first on any non-trivial change, then wait for my go.
- Keep files under ~300 lines when practical.
- When you finish a change, tell me exactly what to run to verify it.
```

---

## 2. Start a New App (Lovable / Bolt / Cursor / Claude Code)
```
Build [one-sentence product description] for [specific user].

Core features for v1 (must have):
1. [feature 1 – be concrete]
2. [feature 2]
3. [feature 3]

Explicitly out of scope for v1:
- [thing 1]
- [thing 2]

Stack preference: [Next.js + Tailwind + Supabase / or whatever you want]
Design vibe: [clean dark mode / playful game UI / professional SaaS]

Before writing any code, ask me up to 5 clarifying questions (with your suggested defaults). Then produce a short one-page spec I can approve.
```

---

## 3. Add a Feature (safe, plan-first)
```
I want to add [feature name] to this codebase.

Looking at @[relevant files or folders], outline:
1. Exact files you will touch
2. Step-by-step plan
3. What will NOT change
4. How I will verify it works (commands + expected result)

Do not write any code yet. Wait for my approval.
```

---

## 4. Debug / Fix a Bug
```
There is a bug.

What I did: [exact steps]
What I expected: [observable behavior]
What actually happened: [exact error message, stack trace, or screenshot description]
Environment: [browser / Node version / relevant config]

Find the root cause. Propose the smallest safe fix. Do not refactor unrelated code. After the fix, tell me the exact verification steps.
```

---

## 5. Quick UI Polish
```
[Attach screenshot if possible]

Improve the visual design of [component or page] to feel [target vibe: tighter, more game-like, premium, etc.].

Constraints:
- Keep the existing layout structure
- No new dependencies
- Match the current color and spacing system

List the specific changes you will make, then implement them.
```

---

## How to use this pack
1. Start every new project with the Project Rules prompt.
2. Use the Start a New App prompt for greenfield work.
3. For every non-trivial change, force a plan first.
4. Always give the AI a clear definition of “done”.

Feedback or improvements? Reply on X or open an issue once the repo is live.
