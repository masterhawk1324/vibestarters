# Simple Game Systems Pack
**Vibe-coding prompts for common game building blocks**  
Version 1.0 · Free · Aimed at Cursor / Claude Code / Phaser / Godot / Unity beginners

These prompts assume you already have a basic project open. Replace the brackets and attach any relevant files.

---

## 1. Player Controller (2D)
```
Add a responsive 2D player controller.

Requirements:
- Keyboard (WASD or arrows) + optional gamepad
- Acceleration and deceleration feel [snappy / floaty / heavy]
- Jump with coyote time and jump buffering
- Simple ground check
- Clamp movement to the screen or level bounds if needed

Constraints:
- Use the existing physics or movement system in the project
- No new dependencies
- Keep the code in one clean file or the existing Player script

First outline the exact changes and verification steps (how I move and jump to test), then implement.
```

---

## 2. Basic Game Loop + Score
```
Implement a minimal game loop with score.

- Start screen or “Press any key to start”
- Running state with increasing difficulty or spawning
- Score that increments on [event]
- Game over state with restart
- Simple UI for score and game-over message

Keep everything in the existing scene/structure. Plan first, then code.
```

---

## 3. Simple Enemy / Obstacle Spawner
```
Create a spawner for [enemies / obstacles / collectibles].

- Spawn at intervals or based on score
- Randomize position within safe bounds
- Basic movement or behavior
- Clean up off-screen objects
- Optional difficulty ramp

Do not touch the player controller. Plan the files and test method first.
```

---

## 4. Quick Juice / Feedback
```
Add satisfying juice to [action: jump / collect / hit / game over].

Suggestions to consider (pick what fits the vibe):
- Screen shake
- Particle burst
- Sound trigger (if audio is already set up)
- Scale punch or color flash

Keep it lightweight and performant. Implement only after a short plan.
```

---

These are deliberately small so you can ship a playable prototype fast. Combine with the Core Vibe Coding Pack for best results.
