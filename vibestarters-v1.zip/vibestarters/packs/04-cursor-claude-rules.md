# Cursor & Claude Code Rules + Starters
**Drop-in rules and system starters**  
Version 1.0 · Free

---

## Recommended .cursorrules / CLAUDE.md starter
```
# Project Rules

You are a senior engineer pair-programming in this repo.

Always:
- Read relevant files before editing
- Prefer minimal, focused diffs
- Never invent packages, APIs, or config that does not exist
- Ask before adding dependencies
- Plan non-trivial work and wait for approval
- After changes, state the exact commands to verify

Stack: [fill in your stack]
Style preferences: [clean, typed, no over-abstraction]

When debugging: demand the exact error + reproduction steps.
When building UI: prefer existing components and design tokens.
```

---

## One-shot “become useful immediately” prompt
```
Read the project structure and the main config files.
Summarize in 5 bullet points:
1. What this project is
2. Current stack
3. Key entry points
4. Any obvious TODOs or rough edges
5. The safest first place to make a small improvement

Do not write code yet.
```

---

## Safe refactor prompt
```
I want to refactor [specific area] for clarity / performance / consistency.

Constraints:
- Behavior must stay identical
- No new dependencies
- Keep the public API the same
- Show the before/after diff plan first

After I approve, implement in the smallest steps possible and verify with [tests or manual checks].
```

---

Put the rules file in the root of every serious project. It dramatically reduces hallucinated APIs and scope creep.
